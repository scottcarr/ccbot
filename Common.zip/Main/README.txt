﻿* ReviewBot does not have any built-in string 
  - ALMOST: it has one string to dynamically loading a Roslyn dll
  - For the moment look in ReviewBot.UsingHelpers.cs for the string  C:\cci\Microsoft.Research\Imported\Tools\Roslyn\v4.5.1\Microsoft.CodeAnalysis.CSharp.Features.dll
      